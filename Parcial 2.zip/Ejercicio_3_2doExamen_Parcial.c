//Javier
//Everardo
//Francisco
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

void menu(){
printf("\n         ");
	printf("\n        ");
	printf("\n 				|:: JUEGO DE NOMBRES ::|");
	printf("\n        ");
	printf("\n            1 - Iniciar					     ");
	printf("\n            2 - Imprimir nombres                                  ");
	printf("\n            3 - Finalizar juego                                   ");
    printf("\n        ");
	printf("\n         Elija una opcion: ");
}

typedef struct nodo{
	int dato;
	char nom[60];
	struct nodo *siguiente;
}nodo;

nodo *primero = NULL;
nodo *ultimo  = NULL;
nodo *aux     = NULL;

void desplegarLista();
void crearLista();

int main(){
	int opcionmenu = 0;
	do
	{
		menu();
		scanf("%i", &opcionmenu);
		switch(opcionmenu){
			case 1:
				printf("\n       Iniciar juego\n");
				crearLista();
				break;
			case 2:
				printf("\n      Imprimir Nombres de los jugadores\n");
				desplegarLista();
				break;			
			case 3:
				printf("\n\n    Juego finalizado...\n\n");
				break;			
			default:
				printf("\n\n Opcion no Valida \n\n");
		}
	} while (opcionmenu != 3);
	return 0;
}

void crearLista(){
	if(primero!=NULL){
		nodo *actual = (nodo*)malloc(sizeof(nodo));
		actual=primero;
	do{
			free(actual);
			actual = actual->siguiente;	
		}while (actual != primero);
		primero = NULL;
		ultimo = NULL;
	}

	int crealis;
	int j = 1;
	int k;
	char nombresito[60];
	bool ver = false;
	printf("\n   Cuantos jugadores quieres agregar: ");
	scanf("%i",&crealis);
	for (int i = 0; i < crealis; ++i)
	{
		
				
			if (primero == NULL){
				nodo *nuevo = (nodo*)malloc(sizeof(nodo));
				printf("\n  Jugador (%i) Escriba su nombre: ",j);
				fflush(stdin);
				gets(nuevo->nom);
				
				primero             = nuevo;
				primero ->siguiente = primero;
				ultimo              = primero;
			}
			else{
		printf("\n");
		nodo *actual = (nodo*)malloc(sizeof(nodo));
		actual = primero;
		do{
			printf("\n  Jugador (%i) escriba los nombres de los jugadores anteriores: ",j);
				fflush(stdin);
				gets(nombresito);
				if (strncmp(nombresito,actual->nom,3)==0){
					ver=true;
				}
				else{
					ver=false;
					break;
				}
				k++;
			actual = actual->siguiente;	
		}while (actual != primero);
	
		if (ver==true){
			nodo *nuevo = (nodo*)malloc(sizeof(nodo));
			printf("\n  Jugador (%i) escriba su nombre: ",j);
				fflush(stdin);
				gets(nuevo->nom);
					ultimo->siguiente = nuevo;
					nuevo->siguiente  = primero;
					ultimo            = nuevo;
				}
		else if (ver==false){
			printf("\n  Jugador (%i) eliminado",j);
		}
			}
			j++;
	}
}

void desplegarLista(){
	nodo *actual = (nodo*)malloc(sizeof(nodo));
	actual = primero;
	if (primero != NULL){
		printf("\n     Los Nombres ganadores son\n\n");
		do{
			printf("     |%s|",actual->nom);
			actual = actual->siguiente;	
		}while (actual != primero);
	}
	else{
		printf("La lista esta vacia\n");
	}
}