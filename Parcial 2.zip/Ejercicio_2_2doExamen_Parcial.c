//Javier
//Everardo
//Francisco
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void menu(){
printf("\n         ");
	printf("\n        |:: Aeropuerto Internacional CDM ::|\n");
	printf("\n            1 - Crear Lista de pasajeros					     ");
	printf("\n            2 - Ingresar pasajero                                  ");
	printf("\n            3 - Eliminar pasajero                                  ");
	printf("\n            4 - Imprimir Lista                                     ");
	printf("\n            5 - Finalizar...                                               ");
	printf("\n\n         Elija una opcion: ");
}

int menuDesplegarLista(){
	int a;
	printf("\n             Como deseas imprimir la lista: \n");
printf("\n               1 - Lista del Primero al Ultimo					     ");
printf("\n               2 - Lista del Ultimo al Primero                        ");
printf("\n\n       Elija una Opcion: ");
scanf("%i", &a);
return a;
}

typedef struct nodo{
	int dato;
	char nom[60];
	char aeroLinea[60];
	char horaSali[60];
	char dest[60];
	struct nodo *siguiente;
	struct nodo *atras;
}nodo;

nodo *primero = NULL;
nodo *ultimo  = NULL;
nodo *aux     = NULL;

void desplegarListaPU();
void desplegarListaUP();
void eliminarNodo();
void crearLista();
void agregarNodoCabeza();


int main(){
	int opcionmenu = 0;
	do
	{
		menu();
		scanf("%i", &opcionmenu);
		switch(opcionmenu){
			case 1:
				printf("\n\n    Crear Lista de Pasajeros\n");
				crearLista();
				break;
			case 2:
				printf("\n\n    Ingresar pasajero \n");
				agregarNodoCabeza();
				break;
			case 3: 
				printf("\n\n Eliminar pasajero\n");
				eliminarNodo();
				break;
			case 4:
				printf("\n  Imprimir Lista de Pasajeros\n");
				int a = menuDesplegarLista();
				printf("\n");
				switch(a){
				case 1:
					desplegarListaPU();
					break;
				case 2:
					desplegarListaUP();
					break;
				}
				break;
			case 5:
				printf("\n\n    Programa finalizado...\n\n");
				break;			
			default:
				printf("\n\n Opcion no Valida \n\n");
		}
	} while (opcionmenu != 5);
	return 0;
}

void crearLista(){
	if (primero==NULL){
	int crealis;
	printf("\n   Cuantos Pasajeros quieres agregar: ");
	scanf("%i",&crealis);
		for (int i = 0; i < crealis; ++i){
			nodo *nuevo = (nodo*)malloc(sizeof(nodo));
			printf("\n   Ingrese nombre del pasajero: ");
				fflush(stdin);
				gets(nuevo->nom);
			printf("\n   Ingrese nombre de la Aerolinea: ");	
				fflush(stdin);
				gets(nuevo->aeroLinea);
			printf("\n   Ingrese Destino: ");	
				fflush(stdin);
				gets(nuevo->dest);
			printf("\n   Ingrese Hora de Salida: ");	
				fflush(stdin);
				gets(nuevo->horaSali);
			if (primero == NULL){
				primero             = nuevo;
				primero ->siguiente = NULL;
				nuevo->atras        = ultimo;
				ultimo              = primero;
			}
			else{
			ultimo->siguiente = nuevo;
			nuevo->siguiente  = NULL;
			nuevo->atras      = ultimo;
			ultimo            = nuevo;
			}
	printf("\n  Pasajero agregado correctamente\n\n");	
		}
	}
	else{
	printf("\n       Ya se habia creado una lista \n");
	}	
}

void agregarNodoCabeza(){
	nodo *nuevo = (nodo*)malloc(sizeof(nodo));
			printf("\n   Ingrese nombre del pasajero: ");
				fflush(stdin);
				gets(nuevo->nom);
			printf("\n   Ingrese nombre de la Aerolinea: ");	
				fflush(stdin);
				gets(nuevo->aeroLinea);
			printf("\n   Ingrese Destino: ");	
				fflush(stdin);
				gets(nuevo->dest);
			printf("\n   Ingrese Hora de Salida: ");	
				fflush(stdin);
				gets(nuevo->horaSali);
	if (primero == NULL){
		primero             = nuevo;
		primero ->siguiente = NULL;
		nuevo->atras        = ultimo;
		ultimo              = primero;
	}
	else{
		nuevo->siguiente = primero;
		primero->atras   = nuevo;
		nuevo->atras     = NULL;
		primero          = nuevo;
		}
	printf("\n Nodo ingresado correctamente\n");
}

void eliminarNodo(){
	nodo *actual = (nodo*)malloc(sizeof(nodo));
	actual = primero;
	nodo *anterior = (nodo*) malloc(sizeof(nodo));
	anterior = NULL;
	char nombreEliminar[60];
	int nodoBuscado = 0, encontrado = 0;
	printf("\n   Ingresa el nombre del pasajero para eliminar: ");
	fflush(stdin);
	gets(nombreEliminar);
	if (primero != NULL){
		while (actual != NULL && encontrado != 1){
			if (strcmp(actual->nom, nombreEliminar)==0){
				if (actual == primero){
					primero = primero->siguiente;
					primero->atras = NULL;
				}
				else if(actual == ultimo){
					anterior->siguiente = NULL;
					ultimo = anterior;
				}
				else{
					anterior->siguiente=actual->siguiente;
					actual->siguiente->atras = anterior;
				}
				printf("\n Pasajero eliminado con exito\n");
				encontrado = 1;
			}
			anterior = actual;
			actual   = actual->siguiente;	
		}
		if (encontrado == 0){
			printf("\n Pasajero no encontrado\n");
		}
		else{
			free(anterior);
		}
	}
	else{
		printf("La lista esta vacia\n");
	}
}

void desplegarListaPU(){
	nodo *actual = (nodo*)malloc(sizeof(nodo));
	actual = primero;
	if (primero != NULL){
		printf("\n");
		printf("\t    Pasajero      ||       Aerolinea      ||      Destino          ||       Hora de Salida \n");
		printf("\t  __________________________________________________________________________________________________\n");
		while (actual != NULL){
			printf("\n\t    %s         ||       %s        ||          %s              ||       %s   \n", actual->nom,actual->aeroLinea,actual->dest,actual->horaSali);
			actual = actual->siguiente;	
		}
	}
	else{
		printf("\n     La lista esta vacia\n");
	}
}

void desplegarListaUP(){
	nodo *actual = (nodo*)malloc(sizeof(nodo));
	actual = ultimo;
	if (primero != NULL){
		printf("\n");
		printf("\t    Pasajero      ||       Aerolinea      ||      Destino          ||       Hora de Salida \n");
		printf("\t  __________________________________________________________________________________________________\n");
		while (actual != NULL){
			printf("\n\t    %s         ||       %s        ||          %s              ||       %s   \n", actual->nom,actual->aeroLinea,actual->dest,actual->horaSali);
			actual = actual->atras;	
		}
	}
	else{
		printf("\n     La lista esta vacia\n");
	}
}